#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#define MAX_NOMBRE 50
#define MAX_EDAD 100
#define LECTURA "%i;%[^;];%i;%c\n"
#define ESCRITURA "%i;%s;%i;%c\n"
#define ERROR_COMANDO_INEXISTENTE -1
#define ERROR_CANTIDAD_PARAMETROS_INVALIDA -2
#define ERROR_ARCHIVO_PRINCIPAL_NO_DISPONIBLE -3
#define ERROR_ARCHIVO_AUX_NO_DISPONIBLE -4
#define ARCHIVO_NUEVO_HEROES_CREADO -5
#define ERROR_ID_EXISTENTE -6
#define ERROR_EDAD_INVALIDA -7
#define ERROR_ID_INVALIDO -8
#define ERROR_ID_NO_ENCONTRADO -9
#define ERROR_NO_SE_EJECUTO_NADA -10
#define ERROR_ESTADO_INVALIDO -11
#define ERROR_NOMBRE_INVALIDO -12
#define NO_HAY_ERRORES 0

const char VIVO = 'V';
const char MUERTO = 'M';
typedef struct super {
	int id;
	char nombre[MAX_NOMBRE];
	int edad;
	char estado;
} super_t;

/*/PRE:
	POST: Lista todas las lineas de un .csv
*/
int listar (char* argv[], int argc){
	if (argc != 3){
		return ERROR_CANTIDAD_PARAMETROS_INVALIDA;
	}
	FILE* archivo_heroes = fopen(argv[2], "r");
	if (archivo_heroes == NULL){
		return ERROR_ARCHIVO_PRINCIPAL_NO_DISPONIBLE;

	} else if (archivo_heroes){
		super_t super;
		while (fscanf(archivo_heroes, LECTURA, &super.id, super.nombre, &super.edad, &super.estado) == 4){
			printf("ID:%-14i NOMBRE:%-14s EDAD:%-14i ESTADO:%-14c\n", super.id, super.nombre, super.edad, super.estado);
			
		}
		fclose(archivo_heroes);
	}
	return NO_HAY_ERRORES;
}
/*PRE:
  POST: Imprime en pantalla todos los comandos disponibles.
*/
int ayuda (int argc){
	if (argc != 2){ 
		return ERROR_CANTIDAD_PARAMETROS_INVALIDA;
	}
	printf("LISTA DE COMANDOS DISPONIBLES:\n");
	printf("• ./ejecutable listar [nombre].csv\n");
	printf("• ./ejecutable contactar ID [nombre].csv\n");
	printf("• ./ejecutable modificar ID EDAD ESTADO [nombre].csv\n");
	printf("• ./ejecutable agregar ID NOMBRE EDAD ESTADO [nombre].csv\n");
	printf("• ./ejecutable ayuda\n");
	
	return NO_HAY_ERRORES;
}
/* PRE:
   POST: Imprime en pantalla el super heroe indicado por ID y lo elimina del .csv
*/ 
int contactar(char* argv[], int argc){
	if (argc != 4){
		return ERROR_CANTIDAD_PARAMETROS_INVALIDA;
	}
	FILE* archivo_heroes = fopen(argv[3], "r");
	if (archivo_heroes == NULL){
		printf("El archivo para contactar no existe!\n");
		return ERROR_ARCHIVO_PRINCIPAL_NO_DISPONIBLE;
	}
	FILE* archivo_aux = fopen("archivo_aux.csv", "w");
	if (archivo_aux == NULL){
		printf("El archivo auxiliar no existe!\n");
		fclose(archivo_heroes);
		return ERROR_ARCHIVO_AUX_NO_DISPONIBLE;
	}
	super_t super;
	int id_ingresado = atoi(argv[2]);
	bool encontrado = false;


	while (fscanf(archivo_heroes, LECTURA, &super.id, super.nombre, &super.edad, &super.estado) == 4){ 
		if(super.id == id_ingresado){
			printf("SUPER HEROE CONTACTADO!.\n");
			printf(ESCRITURA, super.id, super.nombre, super.edad, super.estado);
			encontrado = true;
		}else {
			fprintf(archivo_aux, ESCRITURA, super.id, super.nombre, super.edad, super.estado);
		}
		
	}

	if(!encontrado){
		printf("ESE SUPER HEROE NO EXISTE!");
	}

	rename("archivo_aux.csv", argv[3]);
	fclose(archivo_heroes);
	fclose(archivo_aux);
	return NO_HAY_ERRORES;
}
/* PRE: Archivo ordenado.
   POST: Modifica el estado y edad de un super heroe. Se informa que se modifico.
*/
int modificar(char* argv[], int argc){
	if (argc != 6){
		return ERROR_CANTIDAD_PARAMETROS_INVALIDA;
	}
	FILE* archivo_heroes = fopen(argv[5], "r");
	if (archivo_heroes == NULL){
		return ERROR_ARCHIVO_PRINCIPAL_NO_DISPONIBLE;
	}
	FILE* archivo_aux = fopen("archivo_aux.csv", "w");
	if (archivo_aux == NULL){
		return ERROR_ARCHIVO_AUX_NO_DISPONIBLE;
	}
	
	super_t super;
	int id_ingresado = atoi(argv[2]);
	int edad_ingresada = atoi(argv[3]);
	char* estado_ingresado = argv[4];
	if (edad_ingresada > 100){
		return ERROR_EDAD_INVALIDA;
	}

	if (*estado_ingresado != VIVO && *estado_ingresado != MUERTO){
		return ERROR_ESTADO_INVALIDO;
	}
	
	bool id_encontrado = false;
	while(fscanf(archivo_heroes, LECTURA, &super.id, super.nombre, &super.edad, &super.estado) == 4){
		if (id_ingresado == super.id){
			fprintf(archivo_aux, ESCRITURA, super.id, super.nombre, edad_ingresada, *estado_ingresado);
			id_encontrado = true;
			printf("Personaje modificado con exito!\n");
			printf("ID: %i | NOMBRE: %s | EDAD: %i | ESTADO: %c \n", super.id, super.nombre, edad_ingresada, *estado_ingresado);
			

		} else {
			fprintf(archivo_aux, ESCRITURA, super.id, super.nombre, super.edad, super.estado);
		}
	}
	
	fclose(archivo_heroes);
	fclose(archivo_aux);
	rename("archivo_aux.csv", argv[5]);

	if(!id_encontrado){
		return ERROR_ID_NO_ENCONTRADO;
	}


	return NO_HAY_ERRORES;
}
/*/PRE: El archivo tiene que estar ordenado.
   POST: Agrega un nuevo heroe con nuevos datos.
*/
int agregar (char* argv[], int argc){
	if (argc != 7){
		return ERROR_CANTIDAD_PARAMETROS_INVALIDA;
	}

	int id_ingresado = atoi(argv[2]);
	char* nombre_ingresado = argv[3];
	int edad_ingresada = atoi(argv[4]);
	char* estado_ingresado = argv[5];
	if (edad_ingresada > 100){
		return ERROR_EDAD_INVALIDA;
	}

	if(strlen(nombre_ingresado) >= 50){
		return ERROR_NOMBRE_INVALIDO;
	}

	if (id_ingresado < 0){
		return ERROR_ID_INVALIDO;
	}
	if (*estado_ingresado != VIVO && *estado_ingresado != MUERTO){
		return ERROR_ESTADO_INVALIDO;
	}

	FILE* archivo_heroes = fopen(argv[6], "r");
	if (archivo_heroes == NULL){
		FILE* nuevo_archivo = fopen(argv[6], "w");
		fprintf(nuevo_archivo, ESCRITURA, id_ingresado, nombre_ingresado, edad_ingresada, *estado_ingresado);
		printf("El superheroe -%s- ha sido agregado correctamente a un nuevo archivo!", nombre_ingresado);
		fclose(nuevo_archivo);
		return ARCHIVO_NUEVO_HEROES_CREADO;
	}
	FILE* archivo_aux = fopen("archivo_aux.csv", "w");
	if (archivo_aux == NULL){
		printf("No se pudo crear un archivo auxiliar.");
		return ERROR_ARCHIVO_AUX_NO_DISPONIBLE;
	}

	super_t super;
	bool colocado = false;

	while(fscanf(archivo_heroes, LECTURA, &super.id, super.nombre, &super.edad, &super.estado) == 4){
		if (id_ingresado == super.id){
			colocado = true;
			printf("No se puede agregar este personaje.\n");
		}
		else if(id_ingresado < super.id && !colocado){
			fprintf(archivo_aux, ESCRITURA, id_ingresado, nombre_ingresado, edad_ingresada, *estado_ingresado);
			printf("El superheroe -%s- ha sido agregado correctamente", nombre_ingresado);
			colocado = true;
		}
		fprintf(archivo_aux, ESCRITURA, super.id, super.nombre, super.edad, super.estado);
	}

	if(!colocado){
		fprintf(archivo_aux, ESCRITURA, id_ingresado, nombre_ingresado, edad_ingresada, *estado_ingresado);
		printf("El superheroe -%s- ha sido agregado correctamente", nombre_ingresado);
	}

	fclose(archivo_heroes);
	fclose(archivo_aux);
	rename("archivo_aux.csv", argv[6]); 
	return NO_HAY_ERRORES;
}
/*/PRE:
   POST: Imprime todos los errores y si se creo un archivo auxiliar, si se creo un archivo de heroes
   o si se ejecuto bien el programa.
*/
void imprimir_estado_actual(int estado){
	if (estado == ERROR_COMANDO_INEXISTENTE){
		printf("ERROR: El comando ingresado no existe.\n");
	}
	else if (estado == ERROR_CANTIDAD_PARAMETROS_INVALIDA){
		printf("ERROR: Cantidad de parametros invalida.\n");
	}
	else if (estado == ERROR_ARCHIVO_PRINCIPAL_NO_DISPONIBLE){
		printf("ERROR: Archivo principal no disponible.\n");
	}
	else if (estado == ERROR_ARCHIVO_AUX_NO_DISPONIBLE){
		printf("ERROR: Archivo auxiliar no disponible.\n");
	}
	else if (estado == ARCHIVO_NUEVO_HEROES_CREADO){
		printf("Archivo nuevo de heroes creado!\n");
	}
	else if (estado == ERROR_ID_EXISTENTE){
		printf("ERROR: El ID que ingresaste ya existe.\n");
	}
	else if (estado == NO_HAY_ERRORES){
		printf("Programa ejecutado con exito.\n");
	}
	else if (estado == ERROR_EDAD_INVALIDA){
		printf("ERROR: Edad invalida. (TIENE QUE SER MENOR QUE 100)\n");
	}
	else if (estado == ERROR_ID_INVALIDO){
		printf("ERROR: ID Invalido. (ID TIENE QUE SER MAYOR A 0)\n");
	}
	else if (estado == ERROR_ID_NO_ENCONTRADO){
		printf("ERROR: ID inexistente.\n");
	}
	else if (estado == ERROR_NO_SE_EJECUTO_NADA){
		printf("ERROR: No estas haciendo nada.");
	}
	else if (estado == ERROR_ESTADO_INVALIDO){
		printf("ERROR: El estado ingresado es invalido.");
	}
	else if (estado == ERROR_NOMBRE_INVALIDO){
		printf("ERROR: Nombre demasiado largo.");
	}
}
int main(int argc, char* argv[]){
	int estado = ERROR_NO_SE_EJECUTO_NADA;
	if (strcmp(argv[1], "listar") == 0){
		estado = listar(argv, argc);
	} else if (strcmp(argv[1], "ayuda") == 0){
		estado = ayuda(argc);
	} else if (strcmp(argv[1], "contactar") == 0){
		estado = contactar(argv, argc);
	} else if (strcmp (argv[1], "agregar") == 0){
		estado = agregar (argv, argc);
	} else if (strcmp(argv[1], "modificar") == 0){
		estado = modificar (argv, argc);
	} else {
		estado = ERROR_COMANDO_INEXISTENTE;
	}
	imprimir_estado_actual(estado);
	
	return 0;
}